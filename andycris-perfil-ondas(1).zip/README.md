<!-- ANDYARA CRISTINA · GitHub profile · Black / Blue / Magenta -->
<div align="center">
  <img src="./assets/ondas-neon.gif" width="100%" alt="Ondas de luz azul e magenta em movimento" />
  <sub>ANDYCRIS-UI / PROFILE.README</sub>
  <h1>Andyara Cristina</h1>
  <img src="https://readme-typing-svg.demolab.com?font=JetBrains+Mono&weight=600&size=19&duration=3500&pause=1200&color=278BFF&center=true&vCenter=true&width=650&height=46&lines=Engenharia+de+Software;Futura+estudante+de+Nutri%C3%A7%C3%A3o;Python+%7C+Java+%7C+SQL;Em+constante+aprendizado" alt="Formação e estudos em texto animado" />
  <p><b>Engenharia de Software | Futura estudante de Nutrição</b></p>
  <p>Estudando Python, Java e SQL.<br/>Interesse em Cibersegurança e Banco de Dados.<br/>Em constante aprendizado.</p>
  <p>
    <a href="https://github.com/andycris-ui"><img alt="GitHub" src="https://img.shields.io/badge/GitHub-0D0D14?style=for-the-badge&logo=github&logoColor=278BFF"/></a>
    <a href="https://www.linkedin.com/in/andyara-c-91863a423"><img alt="LinkedIn" src="https://img.shields.io/badge/LinkedIn-278BFF?style=for-the-badge&logo=linkedin&logoColor=white"/></a>
    <a href="https://www.instagram.com/andy_cris.a/"><img alt="Instagram" src="https://img.shields.io/badge/Instagram-D946EF?style=for-the-badge&logo=instagram&logoColor=white"/></a>
  </p>
</div>

---

### `01 / SOBRE MIM`

Olá! Sou **Andyara Cristina**, estudante de **Engenharia de Software** e futura estudante de **Nutrição**. Atualmente, estudo **Python, Java e SQL**, com interesse em construir minha trajetória profissional nas áreas de **Cibersegurança ou Banco de Dados**.

Estou em constante aprendizado, buscando ampliar meus conhecimentos e evoluir pessoal e profissionalmente.

```text
andycris-ui@github:~$ whoami
formação atual  : Engenharia de Software
próxima etapa   : Nutrição
estudando       : Python | Java | SQL
interesses      : Cibersegurança | Banco de Dados
status          : Em constante aprendizado
```

### `02 / TECNOLOGIAS EM ESTUDO`

<p align="center">
  <img alt="Python" src="https://img.shields.io/badge/Python-0D0D14?style=for-the-badge&logo=python&logoColor=278BFF"/>
  <img alt="Java" src="https://img.shields.io/badge/Java-0D0D14?style=for-the-badge&logo=openjdk&logoColor=D946EF"/>
  <img alt="SQL" src="https://img.shields.io/badge/SQL-0D0D14?style=for-the-badge&logoColor=278BFF"/>
</p>
<p align="center"><sub>LEARNING  /  PRACTICING  /  EVOLVING</sub></p>

### `03 / ÁREAS DE INTERESSE`

| 🛡️ Cibersegurança | ◈ Banco de Dados |
| :--- | :--- |
| Interesse em segurança da informação e proteção de sistemas e dados. | Interesse em organização, gerenciamento e estruturação de dados. |

### `04 / MINHA JORNADA NO GITHUB`

Este espaço reúne meus estudos, exercícios e minha evolução na programação.

<p align="center">
  <a href="https://github.com/andycris-ui?tab=repositories"><img alt="Explorar meus repositórios" src="https://img.shields.io/badge/EXPLORAR_REPOSITÓRIOS-278BFF?style=for-the-badge&logo=github&logoColor=white"/></a>
</p>

### `05 / CONTATO`

<p align="center">
  <a href="https://github.com/andycris-ui">GitHub</a> &nbsp;•&nbsp;
  <a href="https://www.linkedin.com/in/andyara-c-91863a423">LinkedIn</a> &nbsp;•&nbsp;
  <a href="https://www.instagram.com/andy_cris.a/">Instagram</a>
</p>

<div align="center">
  <img src="./assets/ondas-neon.gif" width="100%" alt="Ondas de luz em movimento no rodapé"/>
  <sub>ALWAYS LEARNING, ALWAYS EVOLVING. · ANDYCRIS-UI</sub>
</div>
